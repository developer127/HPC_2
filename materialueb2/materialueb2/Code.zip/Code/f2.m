function value = f2(x,material)
value = x;