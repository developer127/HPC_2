function value = f1(x,material)
value = ones(size(x,1),1);