function value = OpA(x,Du,material)
value = [ones(size(x,1),1),zeros(size(x,1),1),ones(size(x,1),1)];