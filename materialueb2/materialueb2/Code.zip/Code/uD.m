function value = uD(x)
value = zeros(size(x,1),1);