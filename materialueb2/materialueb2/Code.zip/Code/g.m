function value = g(x,n)
value = zeros(size(x,1),1);